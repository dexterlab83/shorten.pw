Images folder
